import { chessConfig } from '../../../config/chessConfig.config.js'
import { A, AAA } from '../../../utils/utils.js'
import { piecesRender } from '../../../services/P.Render.js'
import { playerTurn } from '../../../services/Turn.js'
import { piecesDetermine } from '../../../services/P.Determinate.js'

export default {
    handleMovingThePiece({ pieceBoxElement, pieceElement }) {
        if ( pieceElement ) {
            pieceElement.remove()
        }

        const pieceBoxElementSelected = A( `#${ this.pieceSelectedPosition }` )
        const pieceElementSelected = AAA( pieceBoxElementSelected, chessConfig.chessPieceSelector )
        pieceBoxElement.append( pieceElementSelected )

        this.removeReady( pieceBoxElementSelected )
        this.removeSelected( pieceBoxElementSelected )
        this.removePiecePotentials( this.pieceSelectedPosition )
        this.removeReady( pieceBoxElementSelected )
        this.resetPieceSelected()
        
        playerTurn.changeTurn()
        piecesDetermine.generateDeterminations()
        piecesRender.resetPiecesBoxListeners()
        piecesRender.addPiecesBoxListeners()
    }
}
