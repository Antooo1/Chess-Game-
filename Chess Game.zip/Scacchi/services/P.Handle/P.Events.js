import handlePieceClick from './P.Events/Click.js'
import handlePieceMouseenter from './P.Events/MouseEnter.js'
import handlePieceMouseleave from './P.Events/MouseLeave.js'

export default {
    ...handlePieceClick,
    ...handlePieceMouseenter,
    ...handlePieceMouseleave,
}
