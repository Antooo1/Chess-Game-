export const A = query => document.querySelector( query )
export const AA = query => [ ...document.querySelectorAll( query ) ]
export const AAA = (element, query) => element.querySelector( query )
export const deepclone = obj => JSON.parse( JSON.stringify( obj ) )

window.A = A;
window.AA = AA;