import { piecesRender } from '../services/P.Render.js';

addEventListener( 'DOMContentLoaded', _ => {
    piecesRender.renderPieces()
})